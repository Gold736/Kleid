package com.kleyd.assistant

/**
 * Разбор голосовых команд Клейда.
 * Клейд управляет всем телефоном: открывает любые приложения, нажимает кнопки,
 * листает, печатает, жмёт «Назад»/«Домой» и т.д.
 */
object Commands {

    enum class Global { BACK, HOME, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, SCREENSHOT, LOCK }
    enum class Dir { UP, DOWN, LEFT, RIGHT }
    enum class Panel { WIFI, BLUETOOTH }

    sealed class Result {
        object Stop : Result()
        object ClearText : Result()
        object Time : Result()
        object Date : Result()
        class OpenApp(val name: String, val youtubeQuery: String?) : Result()
        class GlobalAction(val kind: Global) : Result()
        /** literal = true: направление пальца («свайп влево»); false: «листай вниз» = дальше. */
        class Scroll(val dir: Dir, val literal: Boolean) : Result()
        class Click(val text: String) : Result()
        class TypeText(val text: String) : Result()
        class VolumeChange(val up: Boolean) : Result()
        class Flashlight(val on: Boolean) : Result()
        class OpenPanel(val panel: Panel) : Result()
        class WebSearch(val query: String) : Result()
        class Question(val text: String) : Result()
    }

    private val OPEN_VERBS = setOf(
        "зайди", "зайти", "открой", "открыть", "запусти", "запустить", "включи", "войди", "зайдите"
    )
    private val FILLERS = setOf(
        "в", "на", "приложение", "приложения", "программу", "пожалуйста", "мне", "у", "меня"
    )
    private val STOP_WORDS = setOf("стоп", "хватит", "замолчи", "тихо")
    private val YES = setOf("да", "давай", "подтверждаю", "конечно", "ага", "угу", "точно")
    private val NO = setOf("нет", "не", "отмена", "отмени", "нельзя")
    private val SCROLL_VERBS = setOf(
        "прокрути", "листай", "пролистай", "промотай", "мотай", "крути", "скролль", "проскролль"
    )
    private val SWIPE_VERBS = setOf("свайп", "свайпни", "смахни", "потяни", "проведи", "сдвинь")

    private val typeRegex = Regex(
        "^\\s*(?:напиши|введи|набери|печатай|вставь)\\s+(.+)$", RegexOption.IGNORE_CASE
    )
    private val clickRegex = Regex(
        "^(?:нажми|нажать|тапни|кликни|клик|жми|выбери|коснись|ткни)" +
            "(?:\\s+(?:на|в))?(?:\\s+(?:кнопку|кнопка|вкладку|пункт|значок|иконку|ссылку))?\\s+(.+)$"
    )
    private val youtubeRegex = Regex(
        "(?:найди|поищи|включи|покажи)\\s+(.+?)\\s+(?:в|на)\\s+(?:ютубе|ютуб|ютьюбе|ютюбе|youtube)"
    )
    private val googleRegex1 = Regex("^(?:загугли|погугли)\\s+(.+)$")
    private val googleRegex2 = Regex(
        "^(?:поищи|найди)\\s+(.+?)\\s+(?:в|на)\\s+(?:гугле|гугл|интернете|google)$"
    )

    fun normalize(s: String): String =
        s.lowercase()
            .replace('ё', 'е')
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun has(t: String, vararg parts: String) = parts.any { t.contains(it) }

    fun isYes(raw: String): Boolean {
        val w = normalize(raw).split(" ").filter { it.isNotEmpty() }
        return w.size <= 3 && w.any { it in YES }
    }

    fun isNo(raw: String): Boolean {
        val w = normalize(raw).split(" ").filter { it.isNotEmpty() }
        return w.size <= 3 && w.any { it in NO || it in STOP_WORDS }
    }

    /** raw — команда как распознана (с заглавными), без слова «Клейд». */
    fun parse(raw: String): Result {
        val t = normalize(raw)
        val words = t.split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return Result.Question(t)

        if (words.size <= 3 && words.any { it in STOP_WORDS }) return Result.Stop

        typeRegex.find(raw.trim())?.let { return Result.TypeText(it.groupValues[1].trim()) }

        if (has(t, "очисти поле", "очисти текст", "сотри все", "сотри текст")) return Result.ClearText

        // Кнопки системы
        if (words.size <= 5) {
            if (words.any { it == "назад" || it == "вернись" }) return Result.GlobalAction(Global.BACK)
            if (has(t, "главный экран", "на главную", "домой", "рабочий стол"))
                return Result.GlobalAction(Global.HOME)
            if (has(t, "недавние", "последние приложения", "открытые приложения", "переключи приложение"))
                return Result.GlobalAction(Global.RECENTS)
            if (has(t, "быстрые настройки", "быстрых настроек"))
                return Result.GlobalAction(Global.QUICK_SETTINGS)
            if (has(t, "уведомлени", "шторк")) return Result.GlobalAction(Global.NOTIFICATIONS)
            if (has(t, "скриншот", "снимок экрана", "сфоткай экран"))
                return Result.GlobalAction(Global.SCREENSHOT)
            if (has(t, "заблокируй экран", "заблокируй телефон", "выключи экран", "погаси экран"))
                return Result.GlobalAction(Global.LOCK)
        }

        // Прокрутка и свайпы
        val dir = when {
            words.any { it == "вниз" } -> Dir.DOWN
            words.any { it == "вверх" } -> Dir.UP
            words.any { it == "влево" || it == "налево" } -> Dir.LEFT
            words.any { it == "вправо" || it == "направо" } -> Dir.RIGHT
            else -> null
        }
        val scrollVerb = words.any { it in SCROLL_VERBS }
        val swipeVerb = words.any { it in SWIPE_VERBS }
        if (dir != null && (scrollVerb || swipeVerb || words.size <= 2)) {
            return Result.Scroll(dir, swipeVerb)
        }

        // Нажатие на кнопку по тексту
        clickRegex.find(t)?.let { return Result.Click(it.groupValues[1].trim()) }

        // Поиск
        youtubeRegex.find(t)?.let { return Result.OpenApp("ютуб", it.groupValues[1]) }
        googleRegex1.find(t)?.let { return Result.WebSearch(it.groupValues[1]) }
        googleRegex2.find(t)?.let { return Result.WebSearch(it.groupValues[1]) }

        // Время и дата
        if (has(t, "который час", "сколько времени", "скажи время")) return Result.Time
        if (has(t, "какое сегодня число", "какой сегодня день", "какая сегодня дата", "какое число"))
            return Result.Date

        // Звук, фонарик, панели
        if (has(t, "громче", "прибавь звук", "увеличь громкость", "погромче")) return Result.VolumeChange(true)
        if (has(t, "тише", "убавь звук", "уменьши громкость", "потише")) return Result.VolumeChange(false)
        if (has(t, "фонарик", "фонарь")) {
            return Result.Flashlight(!has(t, "выключи", "погаси", "отключи"))
        }
        val hasVerb = words.any { it in OPEN_VERBS }
        if (hasVerb || words.size <= 3) {
            if (has(t, "вайфай", "вай фай", "wifi", "wi fi", "вифи")) return Result.OpenPanel(Panel.WIFI)
            if (has(t, "блютуз", "блютус", "bluetooth")) return Result.OpenPanel(Panel.BLUETOOTH)
        }

        // Открыть любое приложение
        if (hasVerb) {
            val name = words.filter { it !in OPEN_VERBS && it !in FILLERS }.joinToString(" ")
            if (name.isNotBlank()) return Result.OpenApp(name, null)
        }

        return Result.Question(t)
    }
}
