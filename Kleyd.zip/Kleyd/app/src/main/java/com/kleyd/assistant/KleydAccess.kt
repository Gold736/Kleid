package com.kleyd.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Руки Клейда: служба специальных возможностей.
 * Через неё он нажимает кнопки, листает, печатает и жмёт системные кнопки.
 * Включается один раз вручную: Настройки → Специальные возможности → Клейд.
 */
class KleydAccess : AccessibilityService() {

    companion object {
        @Volatile var instance: KleydAccess? = null

        private val SPOKEN_TO_LABEL = mapOf(
            "вайфай" to "wi fi",
            "вай фай" to "wi fi",
            "вифи" to "wi fi",
            "блютуз" to "bluetooth",
            "блютус" to "bluetooth",
            "ютуб" to "youtube",
            "гугл" to "google"
        )
    }

    enum class TypeResult { OK, NO_FIELD, PASSWORD }

    class Target(val node: AccessibilityNodeInfo, val label: String)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------- Системные кнопки ----------

    fun doGlobal(kind: Commands.Global): Boolean {
        val action = when (kind) {
            Commands.Global.BACK -> GLOBAL_ACTION_BACK
            Commands.Global.HOME -> GLOBAL_ACTION_HOME
            Commands.Global.RECENTS -> GLOBAL_ACTION_RECENTS
            Commands.Global.NOTIFICATIONS -> GLOBAL_ACTION_NOTIFICATIONS
            Commands.Global.QUICK_SETTINGS -> GLOBAL_ACTION_QUICK_SETTINGS
            Commands.Global.SCREENSHOT ->
                if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return false
            Commands.Global.LOCK ->
                if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
        }
        return performGlobalAction(action)
    }

    // ---------- Жесты ----------

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean {
        val p = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, durationMs))
            .build()
        return dispatchGesture(g, null, null)
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }

    private fun bounds(): Rect {
        val r = Rect()
        rootInActiveWindow?.getBoundsInScreen(r)
        if (r.width() < 100 || r.height() < 100) {
            val dm = resources.displayMetrics
            r.set(0, 0, dm.widthPixels, dm.heightPixels)
        }
        return r
    }

    /** literal = true: dir — это куда ведёт палец; false: «вниз/вправо» = смотреть дальше. */
    fun scroll(dir: Commands.Dir, literal: Boolean): Boolean {
        val finger = if (literal) dir else when (dir) {
            Commands.Dir.DOWN -> Commands.Dir.UP
            Commands.Dir.UP -> Commands.Dir.DOWN
            Commands.Dir.RIGHT -> Commands.Dir.LEFT
            Commands.Dir.LEFT -> Commands.Dir.RIGHT
        }
        val r = bounds()
        val cx = r.exactCenterX()
        val cy = r.exactCenterY()
        val dx = r.width() * 0.30f
        val dy = r.height() * 0.30f
        return when (finger) {
            Commands.Dir.UP -> swipe(cx, cy + dy, cx, cy - dy, 300)
            Commands.Dir.DOWN -> swipe(cx, cy - dy, cx, cy + dy, 300)
            Commands.Dir.LEFT -> swipe(cx + dx, cy, cx - dx, cy, 300)
            Commands.Dir.RIGHT -> swipe(cx - dx, cy, cx + dx, cy, 300)
        }
    }

    // ---------- Поиск кнопок на экране ----------

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int = 0) {
        if (n == null || depth > 40) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    private fun labelOf(n: AccessibilityNodeInfo): String =
        (n.text ?: n.contentDescription ?: n.hintText ?: "").toString()

    /** Находит на экране элемент с таким текстом. */
    fun findTarget(query: String): Target? {
        val root = rootInActiveWindow ?: return null
        val spoken = Commands.normalize(query)
        val q = SPOKEN_TO_LABEL[spoken] ?: spoken
        if (q.isBlank()) return null

        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all)

        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        for (n in all) {
            if (!n.isVisibleToUser) continue
            val label = Commands.normalize(labelOf(n))
            if (label.isEmpty()) continue
            val score = when {
                label == q -> 3
                label.startsWith(q) -> 2
                label.contains(q) -> 1
                else -> 0
            }
            if (score > bestScore) {
                best = n
                bestScore = score
                if (score == 3) break
            }
        }
        val found = best ?: return null
        return Target(found, labelOf(found))
    }

    fun performClick(t: Target): Boolean {
        var n: AccessibilityNodeInfo? = t.node
        var depth = 0
        while (n != null && !n.isClickable && depth < 8) {
            n = n.parent
            depth++
        }
        if (n != null && n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        t.node.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    // ---------- Ввод текста ----------

    private fun findField(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null && focused.isEditable) return focused
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all)
        return all.firstOrNull { it.isEditable && it.isVisibleToUser }
    }

    private fun setText(field: AccessibilityNodeInfo, value: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        }
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun typeText(text: String): TypeResult {
        val field = findField() ?: return TypeResult.NO_FIELD
        if (field.isPassword) return TypeResult.PASSWORD // пароли Клейд не печатает
        val current = if (field.isShowingHintText) "" else (field.text?.toString() ?: "")
        val add = if (current.isEmpty()) text.replaceFirstChar { it.uppercase() } else text
        val sep = if (current.isEmpty() || current.endsWith(" ")) "" else " "
        return if (setText(field, current + sep + add)) TypeResult.OK else TypeResult.NO_FIELD
    }

    fun clearText(): TypeResult {
        val field = findField() ?: return TypeResult.NO_FIELD
        if (field.isPassword) return TypeResult.PASSWORD
        return if (setText(field, "")) TypeResult.OK else TypeResult.NO_FIELD
    }
}
