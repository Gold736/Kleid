package com.kleyd.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Круглый объёмный смайлик Клейд. Рисуется в координатах 380x380. */
class KleydView(context: Context) : View(context) {

    enum class Mode { IDLE, THINKING, SPEAKING }

    @Volatile var mode = Mode.IDLE
    @Volatile var running = false     // идёт по полу
    @Volatile var airborne = false    // в прыжке
    @Volatile var facing = 1f         // 1 = вправо, -1 = влево

    private var hearUntil = 0L
    private var landAt = 0L

    val isHearing: Boolean get() = SystemClock.uptimeMillis() < hearUntil

    /** Микрофон слышит звук. */
    fun hear() {
        hearUntil = SystemClock.uptimeMillis() + 500
    }

    /** Клейд приземлился после прыжка. */
    fun land() {
        landAt = SystemClock.uptimeMillis()
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val smile = Path()

    private val EDGE = Color.parseColor("#E39A0B")
    private val MID = Color.parseColor("#FFB920")
    private val LIGHT = Color.parseColor("#FFCF45")
    private val LIGHTER = Color.parseColor("#FFDD73")
    private val FOOT = Color.parseColor("#B26A00")
    private val DARK = Color.parseColor("#4A2E00")
    private val CHEEK = Color.parseColor("#FF8A5C")

    private fun oval(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, color: Int, alpha: Int = 255) {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.alpha = alpha
        rect.set(cx - rx, cy - ry, cx + rx, cy + ry)
        c.drawOval(rect, paint)
    }

    private fun hand(c: Canvas, x: Float, y: Float) {
        oval(c, x, y, 23f, 23f, EDGE)
        oval(c, x - 2f, y - 3f, 20f, 20f, MID)
        oval(c, x - 5f, y - 7f, 14f, 14f, LIGHT)
    }

    private fun strokeSmile(c: Canvas) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 8f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = DARK
        paint.alpha = 255
        c.drawPath(smile, paint)
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = now / 1000f
        val hearing = isHearing
        val m = mode
        val idle = !running && !airborne && m == Mode.IDLE && !hearing

        c.save()
        c.scale(width / 380f, height / 380f)

        // тень на полу (в прыжке меньше)
        val sh = if (airborne) 0.7f else 1f
        oval(c, 190f, 340f, 95f * sh, 12f * sh, Color.BLACK, 36)

        // разворот в сторону движения
        c.translate(190f, 0f)
        c.scale(facing, 1f)
        c.translate(-190f, 0f)

        // сжатие при приземлении, растяжение в прыжке, дыхание в покое
        val sinceLand = now - landAt
        var sx = 1f
        var sy = 1f
        if (sinceLand < 260) {
            val k = sin(sinceLand / 260f * PI.toFloat()) * 0.2f
            sx = 1f + k
            sy = 1f - k
        } else if (airborne) {
            sx = 0.94f
            sy = 1.07f
        } else if (idle) {
            val b = sin(t * 2.2f) * 0.015f
            sx = 1f - b
            sy = 1f + b
        }
        c.translate(190f, 335f)
        c.scale(sx, sy)
        c.translate(-190f, -335f)

        // наклон вперёд при беге
        if (running) c.rotate(6f, 190f, 330f) else if (airborne) c.rotate(-4f, 190f, 330f)

        // ножки
        val step = if (running) sin(t * 14f) * 10f else 0f
        val footY = if (airborne) 304f else 313f
        oval(c, 150f + step, footY, 24f, 12f, FOOT)
        oval(c, 232f - step, footY, 24f, 12f, FOOT)

        // подпрыгивание при беге
        val bob = if (running) -abs(sin(t * 9f)) * 12f else 0f
        c.translate(0f, bob)
        if (m == Mode.SPEAKING) c.rotate(sin(t * 7f) * 2.5f, 190f, 300f)

        // ручки
        val swing = if (running) sin(t * 14f) * 12f else 0f
        val waving = hearing || m == Mode.SPEAKING || (idle && (now % 6000L) < 1500L)
        if (airborne) {
            val up = sin(t * 20f) * 4f
            hand(c, 60f, 150f + up)
            hand(c, 320f, 150f - up)
        } else {
            hand(c, 73f, 215f + swing)
            if (waving) {
                hand(c, 318f + sin(t * 10f) * 8f, 105f)
            } else {
                hand(c, 307f, 212f - swing)
            }
        }

        // тело: слои для объёма
        oval(c, 190f, 185f, 120f, 120f, EDGE)
        oval(c, 182f, 177f, 113f, 113f, MID)
        oval(c, 173f, 168f, 100f, 100f, LIGHT)
        oval(c, 165f, 160f, 82f, 82f, LIGHTER, 140)
        c.save()
        c.rotate(-35f, 128f, 105f)
        oval(c, 128f, 105f, 34f, 17f, Color.WHITE, 178)
        c.restore()

        // глаза: смотрят вперёд при беге, оглядываются в покое
        val blink = (now % 3500L) < 140L
        val look = if (running) 6f else if (idle) sin(t * 1.3f) * 6f else if (m == Mode.THINKING) sin(t * 5f) * 10f else 0f
        val rx = if (hearing) 18f else 15f
        val ry = if (blink) 2.5f else if (m == Mode.SPEAKING) 21f + sin(t * 5f) * 2f else if (hearing || airborne) 27f else 23f
        val ey = if (m == Mode.THINKING) 158f else 168f
        oval(c, 156f + look, ey, rx, ry, DARK)
        oval(c, 222f + look, ey, rx, ry, DARK)
        if (!blink) {
            oval(c, 160f + look, ey - 10f, 5f, 5f, Color.WHITE)
            oval(c, 226f + look, ey - 10f, 5f, 5f, Color.WHITE)
        }

        // щёчки
        val cheekA = if (m == Mode.SPEAKING) (150 + sin(t * 6f) * 60f).toInt() else 128
        oval(c, 124f, 214f, 16f, 16f, CHEEK, cheekA)
        oval(c, 256f, 214f, 16f, 16f, CHEEK, cheekA)

        // брови
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 7f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = DARK
        paint.alpha = 255
        if (m == Mode.SPEAKING) {
            val up = (sin(t * 12f) + 1f) * 4f
            c.drawLine(138f + look, 128f - up, 172f + look, 126f - up, paint)
            c.drawLine(206f + look, 126f - up, 240f + look, 128f - up, paint)
        } else if (m == Mode.THINKING) {
            c.drawLine(138f, 126f, 172f, 134f, paint)
            c.drawLine(206f, 112f, 240f, 108f, paint)
        }

        // рот
        when {
            m == Mode.SPEAKING -> {
                val open = (sin(t * 18f) + 1f) / 2f
                val w = 22f + 10f * abs(sin(t * 11f))
                oval(c, 190f, 242f, w, 6f + 20f * open, DARK)
            }
            m == Mode.THINKING -> {
                smile.reset()
                smile.moveTo(158f, 246f)
                smile.cubicTo(175f, 230f, 205f, 262f, 222f, 246f)
                strokeSmile(c)
            }
            hearing -> oval(c, 190f, 244f, 11f, 13f, DARK)
            else -> {
                smile.reset()
                smile.moveTo(142f, 224f)
                smile.quadTo(190f, 282f, 238f, 224f)
                strokeSmile(c)
            }
        }

        // ищет: точки над головой и лупа в ручке
        if (m == Mode.THINKING) {
            for (i in 0..2) {
                val dy = sin(t * 6f - i * 0.9f) * 6f
                oval(c, 150f + i * 40f, 36f + dy, 8f, 8f, FOOT)
            }
            val lx = 318f + sin(t * 5f) * 6f
            oval(c, lx, 130f, 22f, 22f, LIGHTER, 90)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 7f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = FOOT
            paint.alpha = 255
            c.drawCircle(lx, 130f, 22f, paint)
            c.drawLine(lx - 4f, 152f, 310f, 196f, paint)
        }

        c.restore()
        postInvalidateOnAnimation()
    }
}
