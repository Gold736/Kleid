package com.kleyd.assistant

import android.content.Intent
import android.content.pm.PackageManager

/** Ищет установленное приложение по названию, сказанному голосом. */
object AppFinder {

    class App(val label: String, val pkg: String)

    private val ALIASES = mapOf(
        "ютуб" to listOf("youtube"),
        "ютьюб" to listOf("youtube"),
        "телеграм" to listOf("telegram"),
        "телега" to listOf("telegram"),
        "ватсап" to listOf("whatsapp"),
        "вотсап" to listOf("whatsapp"),
        "вацап" to listOf("whatsapp"),
        "хром" to listOf("chrome"),
        "браузер" to listOf("browser", "chrome"),
        "камера" to listOf("camera", "камера"),
        "галерея" to listOf("gallery", "photos", "галерея", "фото"),
        "фото" to listOf("photos", "gallery", "фото"),
        "настройки" to listOf("settings", "настройки"),
        "карты" to listOf("maps", "карты"),
        "почта" to listOf("gmail", "mail", "почта"),
        "календарь" to listOf("calendar", "календарь"),
        "часы" to listOf("clock", "часы"),
        "будильник" to listOf("clock", "часы"),
        "калькулятор" to listOf("calculator", "калькулятор"),
        "контакты" to listOf("contacts", "контакты"),
        "телефон" to listOf("dialer", "phone", "телефон"),
        "сообщения" to listOf("messaging", "messages", "mms", "сообщения"),
        "плей маркет" to listOf("vending", "play store", "play маркет"),
        "гугл плей" to listOf("vending", "play store", "play маркет"),
        "вк" to listOf("vkontakte", "vk"),
        "вконтакте" to listOf("vkontakte", "vk"),
        "инстаграм" to listOf("instagram"),
        "тикток" to listOf("tiktok", "musically"),
        "вайбер" to listOf("viber"),
        "музыка" to listOf("music", "музыка"),
        "файлы" to listOf("files", "documentsui", "файлы"),
        "заметки" to listOf("notes", "keep", "заметки")
    )

    /** Отрезает окончание, чтобы «музыку» совпадало с «музыка». */
    private fun stem(s: String): String = s.trimEnd('у', 'е', 'а', 'ы', 'и', 'ю', 'я', 'о')

    private fun same(a: String, b: String): Boolean =
        a == b || (a.length >= 3 && b.length >= 3 && (a.startsWith(b) || b.startsWith(a)))

    fun find(pm: PackageManager, spoken: String): App? {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { App(Commands.normalize(it.loadLabel(pm).toString()), it.activityInfo.packageName) }
            .filter { it.pkg != "com.kleyd.assistant" }
        val q = stem(Commands.normalize(spoken))
        if (q.isBlank()) return null

        // 1. известные названия
        for ((key, variants) in ALIASES) {
            if (same(stem(key), q)) {
                apps.firstOrNull { a -> variants.any { v -> a.label.contains(v) || a.pkg.contains(v) } }
                    ?.let { return it }
            }
        }
        // 2. точное совпадение названия
        apps.firstOrNull { stem(it.label) == q }?.let { return it }
        // 3. название содержит сказанное
        apps.firstOrNull { it.label.contains(q) }?.let { return it }
        // 4. любое слово названия
        apps.firstOrNull { a -> a.label.split(" ").any { w -> same(stem(w), q) } }?.let { return it }
        return null
    }
}
