package com.kleyd.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.app.SearchManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class KleydService : Service() {

    companion object {
        private const val CHANNEL = "kleyd"
        @Volatile var isRunning = false
        private val WAKE = setOf("клейд", "клэйд", "клейт", "клэйт", "клеид", "клэид", "клод", "клауд")
    }

    private lateinit var wm: WindowManager
    private lateinit var kleyd: KleydView
    private lateinit var lp: WindowManager.LayoutParams

    private val main = Handler(Looper.getMainLooper())
    private val net = Executors.newSingleThreadExecutor()

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var running = true
    private var speaking = false
    private var thinking = false
    private var awaitingCommand = false
    private var warnedNoRecognizer = false

    private var px = 100f
    private var floorY = 300f
    private var dir = 1f
    private var jumpY = 0f
    private var jumpV = 0f
    private var onGround = true
    private var pauseFrames = 0
    private var dragging = false
    private var moved = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var startPx = 0f
    private var startJump = 0f
    private var sizePx = 0
    private var pitch = 1.0f
    private var rate = 1.0f
    private val beepMuted = mutableListOf<Int>()
    private var sizeDp = 130f
    private var walkSpeed = 2.2f
    private var jumps = true
    private var walkEnabled = true
    private var floorMargin = 8f
    private var screenW = 0
    private var screenH = 0
    private var density = 1f
    private var frame = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        val sp = getSharedPreferences("kleyd", MODE_PRIVATE)
        pitch = sp.getFloat("pitch", 1.0f)
        rate = sp.getFloat("rate", 1.0f)
        sizeDp = sp.getFloat("size", 130f)
        walkSpeed = sp.getFloat("speed", 2.2f)
        jumps = sp.getBoolean("jumps", true)
        walkEnabled = sp.getBoolean("walk", true)
        floorMargin = sp.getFloat("floor", 8f)
        startAsForeground()
        try {
            setupOverlay()
        } catch (e: Exception) {
            stopSelf()
            return
        }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("ru", "RU"))
                // Лучший доступный русский голос (или выбранный в настройках)
                try {
                    val wanted = sp.getString("voice", "") ?: ""
                    val ru = tts?.voices?.filter { it.locale.language == "ru" } ?: emptyList()
                    val chosen = ru.firstOrNull { it.name == wanted } ?: ru.maxByOrNull { it.quality }
                    if (chosen != null) tts?.setVoice(chosen)
                } catch (e: Exception) {
                }
                tts?.setPitch(pitch)
                tts?.setSpeechRate(rate)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post { finishSpeaking() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { finishSpeaking() } }
                })
                ttsReady = true
                main.post { say("Привет! Я Клейд. Скажи: Привет, Клейд, и что сделать.") }
            } else {
                main.post { scheduleListen(500) }
            }
        }
        main.post(moveTick)
    }

    // ---------- Поворот экрана ----------

    private fun readScreenSize(): Pair<Int, Int> {
        var w = resources.displayMetrics.widthPixels
        var h = resources.displayMetrics.heightPixels
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val b = wm.maximumWindowMetrics.bounds
                w = b.width()
                h = b.height()
            } else {
                val real = android.util.DisplayMetrics()
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealMetrics(real)
                w = real.widthPixels
                h = real.heightPixels
            }
        } catch (e: Exception) {
        }
        return Pair(w, h)
    }

    /** Телефон повернули (боком или вверх ногами): пересчитываем «пол» и границы. */
    private fun refreshScreen() {
        if (!::wm.isInitialized || !::lp.isInitialized) return
        val (w, h) = readScreenSize()
        if (w == screenW && h == screenH) return
        screenW = w
        screenH = h
        density = resources.displayMetrics.density
        floorY = (screenH - sizePx - floorMargin * density).coerceAtLeast(0f)
        px = px.coerceIn(0f, (screenW - sizePx).coerceAtLeast(0).toFloat())
        jumpY = jumpY.coerceIn(-floorY, 0f)
        applyPosition()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        refreshScreen()
    }

    // ---------- Overlay ----------

    private fun setupOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        density = dm.density
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        // полный размер экрана, включая панель навигации
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val b = wm.maximumWindowMetrics.bounds
                screenW = b.width()
                screenH = b.height()
            } else {
                val real = android.util.DisplayMetrics()
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealMetrics(real)
                screenW = real.widthPixels
                screenH = real.heightPixels
            }
        } catch (e: Exception) {
        }
        sizePx = (sizeDp * density).toInt()
        px = screenW / 3f
        floorY = screenH - sizePx - floorMargin * density

        kleyd = KleydView(this)
        lp = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = px.toInt()
        lp.y = floorY.toInt()
        wm.addView(kleyd, lp)

        // Клейда можно взять пальцем и поднять; отпустишь — упадёт вниз.
        // Короткое касание — как раньше: Клейд начинает слушать.
        kleyd.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    moved = false
                    downRawX = e.rawX
                    downRawY = e.rawY
                    startPx = px
                    startJump = jumpY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downRawX
                    val dy = e.rawY - downRawY
                    if (!moved && (abs(dx) > 12 * density || abs(dy) > 12 * density)) {
                        moved = true
                        dragging = true
                        onGround = false
                        jumpV = 0f
                    }
                    if (moved) {
                        px = (startPx + dx).coerceIn(0f, (screenW - sizePx).toFloat())
                        jumpY = (startJump + dy).coerceIn(-floorY, 0f)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        dragging = false
                        jumpV = 0f
                        onGround = jumpY >= 0f
                    } else if (!speaking && !thinking) {
                        awaitingCommand = true
                        say("Слушаю")
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    jumpV = 0f
                    onGround = jumpY >= 0f
                    true
                }
                else -> false
            }
        }
    }

    private val moveTick = object : Runnable {
        override fun run() {
            if (!running) return
            frame++
            if (frame % 10 == 0) refreshScreen()

            // пока Клейда держат пальцем — он висит в воздухе с поднятыми ручками
            if (dragging) {
                kleyd.running = false
                kleyd.airborne = true
                applyPosition()
                main.postDelayed(this, 33)
                return
            }

            val busy = speaking || thinking || awaitingCommand || kleyd.isHearing
            val gravity = 0.9f * density

            // прыжок и падение под действием гравитации
            if (!onGround) {
                jumpV += gravity
                jumpY += jumpV
                if (jumpY >= 0f) {
                    jumpY = 0f
                    jumpV = 0f
                    onGround = true
                    kleyd.land()
                }
            }

            // ходит только по низу экрана
            var walking = false
            if (!busy) {
                if (!walkEnabled) {
                    // стоит на месте
                } else if (pauseFrames > 0) {
                    pauseFrames--
                } else {
                    walking = onGround
                    px += dir * walkSpeed * density
                    val maxX = (screenW - sizePx).toFloat()
                    if (px < 0f) { px = 0f; dir = 1f } else if (px > maxX) { px = maxX; dir = -1f }
                    if (Random.nextInt(200) == 0) dir = -dir
                    if (Random.nextInt(220) == 0) pauseFrames = 40 + Random.nextInt(80)
                    if (onGround && jumps && Random.nextInt(250) == 0) {
                        onGround = false
                        jumpV = -11f * density
                    }
                }
            }

            kleyd.running = walking
            kleyd.airborne = !onGround
            kleyd.facing = dir

            applyPosition()
            main.postDelayed(this, 33)
        }
    }

    private fun applyPosition() {
        val newX = px.toInt()
        val newY = (floorY + jumpY).toInt()
        if (newX != lp.x || newY != lp.y) {
            lp.x = newX
            lp.y = newY
            try { wm.updateViewLayout(kleyd, lp) } catch (_: Exception) {}
        }
    }

    // ---------- Слушание ----------

    private val listenTask = Runnable { startRecognizer() }

    // Глушим писк начала распознавания на короткое время
    private val unmuteTask = Runnable { unmuteBeep() }

    private fun muteBeep() {
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            for (st in intArrayOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
                if (!am.isStreamMute(st)) {
                    am.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, 0)
                    beepMuted.add(st)
                }
            }
            main.removeCallbacks(unmuteTask)
            main.postDelayed(unmuteTask, 900)
        } catch (e: Exception) {
        }
    }

    private fun unmuteBeep() {
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            for (st in beepMuted) am.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, 0)
        } catch (e: Exception) {
        }
        beepMuted.clear()
    }

    private fun scheduleListen(delayMs: Long) {
        main.removeCallbacks(listenTask)
        main.postDelayed(listenTask, delayMs)
    }

    private fun startRecognizer() {
        if (!running || speaking || thinking) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            if (!warnedNoRecognizer) {
                warnedNoRecognizer = true
                say("На телефоне нет службы распознавания речи")
            }
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(listener)
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            muteBeep()
            r.startListening(i)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) { if (rmsdB > 5f) kleyd.hear() }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                stopSelf()
                return
            }
            if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                awaitingCommand = false
            }
            if (!speaking && !thinking) {
                scheduleListen(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
            }
        }

        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) {
                awaitingCommand = false
                scheduleListen(300)
                return
            }
            handle(text)
            if (!speaking && !thinking) scheduleListen(300)
        }
    }

    // ---------- Команды ----------

    private var pendingClick: String? = null
    private var pendingUntil = 0L
    private var torchOn = false

    private val RISKY = listOf(
        "отправ", "оплат", "купи", "заказ", "удал", "перевест", "перевод", "подтверд",
        "оформ", "пожертв", "снять", "стер", "сброс", "очист",
        "send", "pay", "delete", "buy", "order", "confirm", "remove"
    )

    private fun isRisky(label: String): Boolean {
        val l = Commands.normalize(label)
        return RISKY.any { l.contains(it) }
    }

    private fun handle(raw: String) {
        val tokens = raw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val heardWake = tokens.any { Commands.normalize(it) in WAKE }
        val pending = pendingClick != null && SystemClock.uptimeMillis() < pendingUntil
        if (!awaitingCommand && !heardWake && !pending) return

        // убираем слово-имя и вступительное «привет»
        var leading = true
        val kept = ArrayList<String>()
        for (tok in tokens) {
            val n = Commands.normalize(tok)
            if (n in WAKE) continue
            if (leading && n == "привет") continue
            leading = false
            kept.add(tok)
        }
        val cmd = kept.joinToString(" ")
        awaitingCommand = false
        if (cmd.isBlank()) {
            awaitingCommand = true
            say("Слушаю")
            return
        }
        execute(cmd)
    }

    /** Нужна служба специальных возможностей — если не включена, ведём в настройки. */
    private fun needAccess(): KleydAccess? {
        val a = KleydAccess.instance
        if (a == null) {
            say("Включи Клейда в специальных возможностях")
            try {
                startActivity(
                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
        return a
    }

    private fun doClick(acc: KleydAccess, target: KleydAccess.Target) {
        if (!acc.performClick(target)) say("Не получилось нажать")
    }

    private fun clickConfirmed(text: String) {
        val acc = needAccess() ?: return
        val target = acc.findTarget(text)
        if (target == null) say("Кнопка пропала с экрана") else doClick(acc, target)
    }

    private fun execute(cmd: String) {
        // ждём подтверждения опасной кнопки
        val pend = pendingClick
        if (pend != null) {
            pendingClick = null
            if (SystemClock.uptimeMillis() < pendingUntil) {
                if (Commands.isYes(cmd)) {
                    clickConfirmed(pend)
                    return
                }
                if (Commands.isNo(cmd)) {
                    say("Хорошо, не нажимаю")
                    return
                }
            }
        }

        when (val r = Commands.parse(cmd)) {
            is Commands.Result.Stop -> {
                tts?.stop()
                finishSpeaking()
            }
            is Commands.Result.OpenApp -> openByName(r.name, r.youtubeQuery)
            is Commands.Result.GlobalAction -> {
                val acc = needAccess() ?: return
                if (!acc.doGlobal(r.kind)) say("Не получилось")
            }
            is Commands.Result.Scroll -> {
                val acc = needAccess() ?: return
                if (!acc.scroll(r.dir, r.literal)) say("Не получилось")
            }
            is Commands.Result.Click -> {
                val acc = needAccess() ?: return
                val target = acc.findTarget(r.text)
                if (target == null) {
                    say("Не вижу на экране ${r.text}")
                } else if (isRisky(target.label)) {
                    pendingClick = r.text
                    pendingUntil = SystemClock.uptimeMillis() + 15000
                    say("Точно нажать ${target.label}? Скажи да или нет")
                } else {
                    doClick(acc, target)
                }
            }
            is Commands.Result.TypeText -> {
                val acc = needAccess() ?: return
                when (acc.typeText(r.text)) {
                    KleydAccess.TypeResult.OK -> {}
                    KleydAccess.TypeResult.NO_FIELD -> say("Не вижу поле для ввода. Нажми на поле")
                    KleydAccess.TypeResult.PASSWORD -> say("В поле пароля я не печатаю")
                }
            }
            is Commands.Result.ClearText -> {
                val acc = needAccess() ?: return
                when (acc.clearText()) {
                    KleydAccess.TypeResult.OK -> {}
                    KleydAccess.TypeResult.NO_FIELD -> say("Не вижу поле для ввода")
                    KleydAccess.TypeResult.PASSWORD -> say("Поле пароля я не трогаю")
                }
            }
            is Commands.Result.VolumeChange -> {
                val am = getSystemService(AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    if (r.up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI
                )
            }
            is Commands.Result.Flashlight -> {
                if (!setTorch(r.on)) say("Не получилось включить фонарик")
            }
            is Commands.Result.OpenPanel -> openPanel(r.panel)
            is Commands.Result.WebSearch -> webSearch(r.query)
            is Commands.Result.Time -> {
                say("Сейчас " + SimpleDateFormat("H:mm", Locale("ru")).format(Date()))
            }
            is Commands.Result.Date -> {
                say("Сегодня " + SimpleDateFormat("d MMMM, EEEE", Locale("ru")).format(Date()))
            }
            is Commands.Result.Question -> ask(r.text)
        }
    }

    private fun openByName(name: String, youtubeQuery: String?) {
        val app = AppFinder.find(packageManager, name)
        if (app == null) {
            say("Не нашёл приложение $name")
            return
        }
        if (youtubeQuery != null && app.pkg == "com.google.android.youtube") {
            try {
                startActivity(
                    Intent(Intent.ACTION_SEARCH)
                        .setPackage(app.pkg)
                        .putExtra("query", youtubeQuery)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                say("Ищу $youtubeQuery на ютубе")
                return
            } catch (e: Exception) {
                // откроем просто YouTube
            }
        }
        val launch = packageManager.getLaunchIntentForPackage(app.pkg)
        if (launch == null) {
            say("Не получилось открыть $name")
            return
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(launch)
            say("Открываю $name")
        } catch (e: Exception) {
            say("Не получилось открыть $name")
        }
    }

    private fun webSearch(query: String) {
        try {
            startActivity(
                Intent(Intent.ACTION_WEB_SEARCH)
                    .putExtra(SearchManager.QUERY, query)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e2: Exception) {
                say("Не получилось открыть поиск")
            }
        }
    }

    private fun openPanel(panel: Commands.Panel) {
        val action = when (panel) {
            Commands.Panel.WIFI ->
                if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                else Settings.ACTION_WIFI_SETTINGS
            Commands.Panel.BLUETOOTH -> Settings.ACTION_BLUETOOTH_SETTINGS
        }
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            say("Открываю")
        } catch (e: Exception) {
            say("Не получилось открыть")
        }
    }

    private fun setTorch(on: Boolean): Boolean {
        return try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(id, on)
            torchOn = on
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun ask(question: String) {
        thinking = true
        kleyd.mode = KleydView.Mode.THINKING
        recognizer?.cancel()
        net.execute {
            val answer = WebAnswer.ask(question)
            main.post {
                thinking = false
                say(answer ?: "Не нашёл ответ в интернете")
            }
        }
    }

    // ---------- Голос ----------

    private fun say(text: String) {
        speaking = true
        kleyd.mode = KleydView.Mode.SPEAKING
        recognizer?.cancel()
        main.removeCallbacks(listenTask)
        if (!ttsReady) {
            finishSpeaking()
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kleyd")
    }

    private fun finishSpeaking() {
        speaking = false
        kleyd.mode = KleydView.Mode.IDLE
        scheduleListen(300)
    }

    // ---------- Служебное ----------

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Клейд", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Клейд слушает")
            .setContentText("Скажи: Привет, Клейд")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        running = false
        isRunning = false
        unmuteBeep()
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        net.shutdownNow()
        try { wm.removeView(kleyd) } catch (_: Exception) {}
        super.onDestroy()
    }
}
